# -*- coding: utf-8 -*-
#
# Copyright (C) 2014 Thomas Amland
# Copyright (C) 2015 Geoff Armstrong ("Audiophile" options only)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from __future__ import unicode_literals

import xbmcgui
import xbmcaddon
import xbmcplugin
from xbmcgui import ListItem
from requests import HTTPError
from lib import wimpy
from lib.wimpy.models import Album, Artist
from lib.wimpy import Quality
from routing import Plugin

# following needed for "Audiophile" functions
import sys, os
import xbmc
import time
import xbmcgui
import xbmcaddon
import xbmcplugin
import subprocess
import signal
import urllib
import random
try:
    import win32com.client
except:
    pass
from sys import platform as _platform

plugin = Plugin()
addon = xbmcaddon.Addon()

quality = [Quality.lossless, Quality.high, Quality.low][int('0'+addon.getSetting('quality'))]
config = wimpy.Config(
    session_id=addon.getSetting('session_id'),
    country_code=addon.getSetting('country_code'),
    user_id=addon.getSetting('user_id'),
    api=wimpy.TIDAL_API if addon.getSetting('site') == '1' else wimpy.WIMP_API,
    quality=quality,
)
wimp = wimpy.Session(config)


def view(data_items, urls, end=True):
    list_items = []
    for item, url in zip(data_items, urls):
        li = ListItem(item.name)
        info = {'title': item.name}
        if isinstance(item, Album):
            info.update({'album': item.name, 'artist': item.artist.name})
        elif isinstance(item, Artist):
            info.update({'artist': item.name})
        li.setInfo('music', info)
        if getattr(item, 'image', None):
            li.setThumbnailImage(item.image)
        list_items.append((url, li, True))
    xbmcplugin.addDirectoryItems(plugin.handle, list_items)
    if end:
        xbmcplugin.endOfDirectory(plugin.handle)


#def track_list(tracks):
#    xbmcplugin.setContent(plugin.handle, 'songs')
#    list_items = []
#    for track in tracks:
#        if not track.available:
#            continue
#        url = plugin.url_for(play, track_id=track.id)
#        li = ListItem(track.name)
#        li.setProperty('isplayable', 'true')
#        li.setInfo('music', {
#            'title': track.name,
#            'tracknumber': track.track_num,
#            'discnumber': track.disc_num,
#            'artist': track.artist.name,
#            'album': track.album.name})
#        if track.album:
#            li.setThumbnailImage(track.album.image)
#        radio_url = plugin.url_for(track_radio, track_id=track.id)
#        li.addContextMenuItems(
#            [('Track Radio', 'XBMC.Container.Update(%s)' % radio_url,)])
#        list_items.append((url, li, False))
#    xbmcplugin.addDirectoryItems(plugin.handle, list_items)
#    xbmcplugin.endOfDirectory(plugin.handle)


# coding for "Audiophile" options by Geoff Armstrong

def track_list(tracks):
    """ First check if the audiophile setting is on """
    """ If not apply normal processing """
    if addon.getSetting('audiophile') == 'true':
        sleepTime = 5
        if addon.getSetting('repeat') == 'true':
            repeat = 100
        else:
            repeat = 1
        for x in range(0, repeat):
            theTracks = get_tracks(tracks)
            do_list(theTracks)
            stop_current()
            time.sleep(sleepTime)
            check_for_stop()
            if addon.getSetting('gapless') == 'true':
                do_gapless(theTracks)
            else:
                interlude = int(addon.getSetting('interlude'))
                playlistName = 'TidalNow.m3u8'
                interrupt = False
                for track in theTracks:
                    if not track.available:
                        continue
                    url = plugin.url_for(play, track_id=track.id)
                    media_url = wimp.get_media_url(track.id)
                    thisUrl = '#EXTM3U'
                    thisUrl += '\n'
                    thisUrl += media_url
                    thisUrl += '\n'
                    totalDuration = track.duration + interlude
                    i = sleepTime
                    write_external_playlist(thisUrl, playlistName)
                    if track.album:
                        imageName = 'imageNow.jpg'
                        display_image(imageName, track.album.image)
                    while totalDuration > i:
                        if check_for_stop():
                            interrupt = True
                            break
                        if (totalDuration - i) > sleepTime:
                            time.sleep(sleepTime)
                        else:
                            time.sleep(totalDuration - i)
                        i += sleepTime
                    if interrupt:
                        return True
                    thisUrl = ''
    else:
        do_list(tracks)

def get_tracks(theTracks):
    """ Determine the tracks to be used depending on settings """
    if addon.getSetting('hqp') == 'true':
        checkfortype = '.flac?'
    else:
        checkfortype = '?'
    if addon.getSetting('shuffle') == 'true':
        if addon.getSetting('sample') == 'false':
            tracks = []
            random.shuffle(theTracks)
            for track in theTracks:
                media_url = wimp.get_media_url(track.id)
                if track.available and checkfortype in media_url:
                    tracks.append(track)
        else:
            albums = []
            tracks = []
            random.shuffle(theTracks)
            for track in theTracks:
                media_url = wimp.get_media_url(track.id)
                if track.available and checkfortype in media_url:
                    if track.album.name not in albums:
                        albums.append(track.album.name)
                        tracks.append(track)
            if len(albums) == 1:
                tracks = theTracks
        random.shuffle(tracks)
    elif addon.getSetting('sample') == 'true':
        albums = []
        tracks = []
        for track in theTracks:
            media_url = wimp.get_media_url(track.id)
            if track.available and checkfortype in media_url:
                if track.album.name not in albums:
                    albums.append(track.album.name)
                    tracks.append(track)
            random.shuffle(tracks)
        if len(albums) == 1:
            media_url = wimp.get_media_url(theTracks[0].id)
            if theTracks[0].available and checkfortype in media_url:
                tracks = theTracks
        random.shuffle(tracks)
    else:
        tracks = theTracks
    print('thetracks ' +str(tracks))
    return tracks


#def get_tracks(theTracks):
#    """ Determine the tracks to be used depending on settings """
#    if addon.getSetting('shuffle') == 'true':
#        if addon.getSetting('sample') == 'false':
#            tracks = []
#            random.shuffle(theTracks)
#            for track in theTracks:
#                tracks.append(track)
#        else:
#            albums = []
#            tracks = []
#            random.shuffle(theTracks)
#            for track in theTracks:
#                if track.album.image not in albums:
#                    albums.append(track.album.image)
#                    tracks.append(track)
#            if len(albums) == 1:
#                tracks = theTracks
#    elif addon.getSetting('sample') == 'true':
#        albums = []
#        tracks = []
#        for track in theTracks:
#            if track.album.image not in albums:
#                albums.append(track.album.image)
#                tracks.append(track)
#            random.shuffle(tracks)
#        if len(albums) == 1:
#            tracks = theTracks
#    else:
#        tracks = theTracks
#    return tracks

def do_list(theTracks):
    """ normal processing previously under track_list """
    xbmcplugin.setContent(plugin.handle, 'songs')
    list_items = []
    for track in theTracks:
        if not track.available:
            continue
        url = plugin.url_for(play, track_id=track.id)
        print('theurl ' +str(url))
        li = ListItem(track.name)
        li.setProperty('isplayable', 'true')
        li.setInfo('music', {
            'title': track.name,
            'tracknumber': track.track_num,
            'discnumber': track.disc_num,
            'artist': track.artist.name,
            'album': track.album.name})
        if track.album:
            li.setThumbnailImage(track.album.image)
        radio_url = plugin.url_for(track_radio, track_id=track.id)
        li.addContextMenuItems(
            [('Track Radio', 'XBMC.Container.Update(%s)' % radio_url,)])
        list_items.append((url, li, False))
    print('handle ' +str(list_items))
    xbmcplugin.addDirectoryItems(plugin.handle, list_items)
    xbmcplugin.endOfDirectory(plugin.handle)



def do_gapless(theTracks, start_track=0, theUrls=''):
    if check_for_stop():
        return
    interrupt = False
    if theUrls == '':
        theUrls = '#EXTM3U\n'
    max_duration = 1900
    playlistName = 'TidalNow.m3u8'
    interlude = int(addon.getSetting('interlude'))
    totalDuration = 0
    the_image = ''
    waitDuration = 0
    i = start_track
    imageName = 'imageNow.jpg'
    currentTracks = []
    currentAlbum = ''
    lastalbum = ''
    sleepTime = 5
    for track in theTracks[start_track:]:
        print('numTracks' +str(len(theTracks)))
        media_url = wimp.get_media_url(track.id)
        if track.available:
            currentTracks.append(track)
            the_image = track.album.image
            totalDuration += track.duration
            if (totalDuration >= max_duration-10) or (totalDuration >= max_duration+10) or (totalDuration >= max_duration):
                waitDuration = totalDuration - track.duration + interlude
                write_external_playlist(theUrls, playlistName)
                if start_track == 0 and addon.getSetting('shuffle') == 'false' and addon.getSetting('sample') == 'false':
                    display_image(imageName, the_image)
                if i < len(theTracks):
                    if addon.getSetting('shuffle') == 'true' or addon.getSetting('sample') == 'true':
                        for thisTrack in currentTracks[:-1]:
                            thisDuration = thisTrack.duration
                            if check_for_stop():
                                currentTracks = []
                                i = len(theTracks)
                                return
#                            if thisTrack.album.name <> lastalbum:
                            display_image(imageName, thisTrack.album.image)
#                                lastalbum = thisTrack.album.name
                            j = sleepTime
                            while thisDuration > j:
                                if check_for_stop():
                                    interrupt = True
                                    break
                                if (thisDuration - j) > sleepTime:
                                    time.sleep(sleepTime)
                                else:
                                    time.sleep(thisDuration - j)
                                j += sleepTime
                            if interrupt:
                                return True
#                            time.sleep(thisDuration)
                        if check_for_stop():
                            i = len(theTracks)
                            return
                        time.sleep(interlude)
                    else:
                        if check_for_stop():
                            i = len(theTracks)
                            return
                        j = sleepTime
                        while waitDuration > j:
                            if check_for_stop():
                                interrupt = True
                                break
                            if (waitDuration - j) > sleepTime:
                                time.sleep(sleepTime)
                            else:
                                time.sleep(waitDuration - j)
                            j += sleepTime
#                        time.sleep(waitDuration)
                    print('tracknum ' +str(i))
                    if check_for_stop():
                        i = len(theTracks)
                        return
                    do_gapless(theTracks, i)
                    break
            else:
                if check_for_stop():
                    i = len(theTracks)
                    return
                theUrls += media_url
                theUrls += '\n'
                if i == len(theTracks)-1:
                    write_external_playlist(theUrls, playlistName)
#                    display_image(imageName, the_image)
        else:
            continue
        i += 1
    return



def write_external_playlist(urls, name):
        """ write the urls to be streamed by external player to playlist with name and launch the player"""
        tidalPlaylist = xbmc.translatePath('special://temp/')
        tidalPlaylist += name
        completeName = os.path.abspath(tidalPlaylist)
        file1 = open(completeName,"w")
        toFile = urls
        file1.write(toFile)
        file1.close
        settingsFile = xbmc.translatePath('special://temp/')
        settingsFile += 'pcm.xml'
        theSettings = os.path.abspath(settingsFile)
        if _platform == "darwin":
            if addon.getSetting('ramdisk') == 'true':
                pathToHQP = '/Volumes/Ramdisk/HQPlayerDesktop.app/Contents/MacOS/HQPlayerDesktop'
            else:
                pathToHQP = '/Applications/HQPlayerDesktop.app/Contents/MacOS/HQPlayerDesktop'
            if addon.getSetting('hqp') == 'true':
                try:
                    """ HQPlayerDesktop is a special case. When it's the chosen player on Mac
                        it must first be quit and then re-opened with the playlist name as argument as follows"""
#                    cmd = """osascript -e 'tell app "HQPlayerDesktop" to quit'"""
                    p = subprocess.Popen(['ps', '-A'], stdout=subprocess.PIPE)
                    out, err = p.communicate()
                    for line in out.splitlines():
                        if 'HQPlayerDesktop' in line:
                            pid = int(line.split(None, 1)[0])
                            os.kill(pid, signal.SIGKILL)
#                    os.system(cmd)
                    try:
                        subprocess.Popen([pathToHQP, completeName, theSettings])
                    except:
                        subprocess.Popen([pathToHQP, completeName])
                except:
                    os.system("open "+completeName)
            else:
                os.system("open "+completeName)
        elif _platform == "win32":
            if addon.getSetting('ramdisk') == 'true':
                pathToHQP = "R:\HQPlayer-desktop.exe"
            else:
                pathToHQP = "C:\Program Files (x86)\Signalyst\HQPlayer Desktop 3\HQPlayer-desktop.exe"
            if addon.getSetting('hqp') == 'true':
#                pathToHQP = "C:\Program Files (x86)\Signalyst\HQPlayer Desktop 3\HQPlayer-desktop.exe"
                """ HQPlayerDesktop is a special case. When it's the chosen player on Windows
                    it must first be quit and then re-opened with the playlist name as argument as follows"""
                try:
                    os.system('TASKKILL /F /IM HQPlayer-desktop.exe')
                    try:
                        subprocess.Popen([pathToHQP, completeName, theSettings])
                    except:
                        subprocess.Popen([pathToHQP, completeName])
                except:
                    os.startfile(completeName, 'open')
            else:
                os.startfile(completeName, 'open')

        elif sys.platform == 'linux2':
            pathToHQP += '/usr/bin/hqplayer'
            if addon.getSetting('hqp') == 'true':
                try:
                    try:
                        subprocess.Popen([pathToHQP, completeName, theSettings])
                    except:
                        subprocess.Popen([pathToHQP, completeName])
                except:
                    subprocess.call(["xdg-open", completeName])
            else:
                subprocess.call(["xdg-open", completeName])


def check_for_stop():
    """ check if STOP has been written to TidalNow playlist """
    try:
        tidalPlaylist = xbmc.translatePath('special://temp/')
        tidalPlaylist += 'TidalNow.m3u8'
        completeName = os.path.abspath(tidalPlaylist)
        file1 = open(completeName,"r")
        theLines=file1.read()
        file1.close
        if theLines == 'STOP':
            file1 = open(completeName,"w")
            file1.write('START')
            file1.close
            return True
        else:
            return False
    except:
        return False

def stop_current():
    """ write STOP to TidalNow playlist """
    """ Any currently running playlist will be interrupted and the new plalist loaded """
    try:
        qobuzPlaylist = xbmc.translatePath('special://temp/')
        qobuzPlaylist += 'QobuzNow.m3u8'
        completeName = os.path.abspath(qobuzPlaylist)
        file1 = open(completeName,"r")
        theLines=file1.read()
        file1.close
        if theLines is not 'STOP':
            file1 = open(completeName,"w")
            file1.write('STOP')
            file1.close
    except:
        pass
    try:
        tidalPlaylist = xbmc.translatePath('special://temp/')
        tidalPlaylist += 'TidalNow.m3u8'
        completeName = os.path.abspath(tidalPlaylist)
        file1 = open(completeName,"r")
        theLines=file1.read()
        file1.close
        if theLines is not 'STOP':
            file1 = open(completeName,"w")
            file1.write('STOP')
            file1.close
            return True
        else:
            return False
    except:
        return False

def display_image(name, the_image):
    tidalImage = xbmc.translatePath('special://temp/')
    tidalImage += name
    imageName = os.path.abspath(tidalImage)
    file1 = open(imageName,"wb")
    file1.write(urllib.urlopen(the_image).read())
    file1.close()
    if _platform == "darwin":
        os.system("open "+imageName)
        cmd = """osascript -e 'tell application "System Events" to set frontmost of process "Preview" to true'"""
        os.system(cmd)
    elif _platform == "win32":
        os.startfile(imageName, 'open')
    elif sys.platform == 'linux2':
        subprocess.call(["xdg-open", imageName])

# end of "Audiophile options"

def add_directory(title, endpoint,):
    if callable(endpoint):
        endpoint = plugin.url_for(endpoint)
    xbmcplugin.addDirectoryItem(plugin.handle, endpoint, ListItem(title), True)


def urls_from_id(view_func, items):
    return [plugin.url_for(view_func, item.id) for item in items]


@plugin.route('/')
def root():
    add_directory('My music', my_music)
    add_directory('Featured Playlists', featured_playlists)
    add_directory("What's New", whats_new)
    add_directory('Genres', genres)
    add_directory('Moods', moods)
    add_directory('Search', search)
    add_directory('Login', login)
    add_directory('Logout', logout)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/track_radio/<track_id>')
def track_radio(track_id):
    track_list(wimp.get_track_radio(track_id))


@plugin.route('/moods')
def moods():
    items = wimp.get_moods()
    view(items, urls_from_id(moods_playlists, items))


@plugin.route('/moods/<mood>')
def moods_playlists(mood):
    items = wimp.get_mood_playlists(mood)
    view(items, urls_from_id(playlist_view, items))


@plugin.route('/genres')
def genres():
    items = wimp.get_genres()
    view(items, urls_from_id(genre_view, items))


@plugin.route('/genre/<genre_id>')
def genre_view(genre_id):
    add_directory('Playlists', plugin.url_for(genre_playlists, genre_id=genre_id))
    add_directory('Albums', plugin.url_for(genre_albums, genre_id=genre_id))
    add_directory('Tracks', plugin.url_for(genre_tracks, genre_id=genre_id))
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/genre/<genre_id>/playlists')
def genre_playlists(genre_id):
    items = wimp.get_genre_items(genre_id, 'playlists')
    view(items, urls_from_id(playlist_view, items))


@plugin.route('/genre/<genre_id>/albums')
def genre_albums(genre_id):
    items = wimp.get_genre_items(genre_id, 'albums')
    view(items, urls_from_id(album_view, items))


@plugin.route('/genre/<genre_id>/tracks')
def genre_tracks(genre_id):
    items = wimp.get_genre_items(genre_id, 'tracks')
    track_list(items)


@plugin.route('/featured_playlists')
def featured_playlists():
    items = wimp.get_featured()
    view(items, urls_from_id(playlist_view, items))


@plugin.route('/whats_new')
def whats_new():
    add_directory('Recommended Playlists', plugin.url_for(featured, group='recommended', content_type='playlists'))
    add_directory('Recommended Albums', plugin.url_for(featured, group='recommended', content_type='albums'))
    add_directory('Recommended Tracks', plugin.url_for(featured, group='recommended', content_type='tracks'))
    add_directory('New Playlists', plugin.url_for(featured, group='new', content_type='playlists'))
    add_directory('New Albums', plugin.url_for(featured, group='new', content_type='albums'))
    add_directory('New Tracks', plugin.url_for(featured, group='new', content_type='tracks'))
    add_directory('Top Albums', plugin.url_for(featured, group='top', content_type='albums'))
    add_directory('Top Tracks', plugin.url_for(featured, group='top', content_type='tracks'))
    add_directory('Local Playlists', plugin.url_for(featured, group='local', content_type='playlists'))
    add_directory('Local Albums', plugin.url_for(featured, group='local', content_type='albums'))
    add_directory('Local Tracks', plugin.url_for(featured, group='local', content_type='tracks'))
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/featured/<group>/<content_type>')
def featured(group=None, content_type=None):
    items = wimp.get_featured_items(content_type, group)
    if content_type == 'tracks':
        track_list(items)
    elif content_type == 'albums':
        view(items, urls_from_id(album_view, items))
    elif content_type == 'playlists':
        view(items, urls_from_id(playlist_view, items))


@plugin.route('/my_music')
def my_music():
    add_directory('My Playlists', my_playlists)
    add_directory('Favourite Playlists', favourite_playlists)
    add_directory('Favourite Artists', favourite_artists)
    add_directory('Favourite Albums', favourite_albums)
    add_directory('Favourite Tracks', favourite_tracks)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/album/<album_id>')
def album_view(album_id):
    xbmcplugin.addSortMethod(plugin.handle, xbmcplugin.SORT_METHOD_TRACKNUM)
    track_list(wimp.get_album_tracks(album_id))


@plugin.route('/artist/<artist_id>')
def artist_view(artist_id):
    xbmcplugin.setContent(plugin.handle, 'albums')
    xbmcplugin.addDirectoryItem(
        plugin.handle, plugin.url_for(top_tracks, artist_id),
        ListItem('Top Tracks'), True
    )
    xbmcplugin.addDirectoryItem(
        plugin.handle, plugin.url_for(artist_radio, artist_id),
        ListItem('Artist Radio'), True
    )
    xbmcplugin.addDirectoryItem(
        plugin.handle, plugin.url_for(similar_artists, artist_id),
        ListItem('Similar Artists'), True
    )
    albums = wimp.get_artist_albums(artist_id) + \
             wimp.get_artist_albums_ep_singles(artist_id) + \
             wimp.get_artist_albums_other(artist_id)
    view(albums, urls_from_id(album_view, albums))


@plugin.route('/artist/<artist_id>/radio')
def artist_radio(artist_id):
    track_list(wimp.get_artist_radio(artist_id))


@plugin.route('/artist/<artist_id>/top')
def top_tracks(artist_id):
    track_list(wimp.get_artist_top_tracks(artist_id))


@plugin.route('/artist/<artist_id>/similar')
def similar_artists(artist_id):
    xbmcplugin.setContent(plugin.handle, 'artists')
    artists = wimp.get_artist_similar(artist_id)
    view(artists, urls_from_id(artist_view, artists))


@plugin.route('/playlist/<playlist_id>')
def playlist_view(playlist_id):
    track_list(wimp.get_playlist_tracks(playlist_id))


@plugin.route('/user_playlists')
def my_playlists():
    items = wimp.user.playlists()
    view(items, urls_from_id(playlist_view, items))


@plugin.route('/favourite_playlists')
def favourite_playlists():
    items = wimp.user.favorites.playlists()
    view(items, urls_from_id(playlist_view, items))


@plugin.route('/favourite_artists')
def favourite_artists():
    xbmcplugin.setContent(plugin.handle, 'artists')
    items = wimp.user.favorites.artists()
    view(items, urls_from_id(artist_view, items))


@plugin.route('/favourite_albums')
def favourite_albums():
    xbmcplugin.setContent(plugin.handle, 'albums')
    items = wimp.user.favorites.albums()
    view(items, urls_from_id(album_view, items))


@plugin.route('/favourite_tracks')
def favourite_tracks():
    track_list(wimp.user.favorites.tracks())


@plugin.route('/search')
def search():
	add_directory('Artist', plugin.url_for(searchtype, field = 'artist'))
	add_directory('Album', plugin.url_for(searchtype, field = 'album'))
	add_directory('Playlist', plugin.url_for(searchtype, field = 'playlist'))
	add_directory('Track', plugin.url_for(searchtype, field = 'track'))
	xbmcplugin.endOfDirectory(plugin.handle)
	
@plugin.route('/searchtype/<field>')
def searchtype(field):
	keyboard = xbmc.Keyboard('', 'Search')
	keyboard.doModal()
	if keyboard.isConfirmed():
		keyboardinput = keyboard.getText()
		if keyboardinput:
			searchresults = wimp.search(field, keyboardinput)
			view(searchresults.artists, urls_from_id(artist_view, searchresults.artists), end = False)
			view(searchresults.albums, urls_from_id(album_view, searchresults.albums), end = False)
			view(searchresults.playlists, urls_from_id(playlist_view, searchresults.playlists), end = False)
			track_list(searchresults.tracks)


@plugin.route('/login')
def login():
    username = addon.getSetting('username')
    password = addon.getSetting('password')

    if not username or not password:
        # Ask for username/password
        dialog = xbmcgui.Dialog()
        username = dialog.input('Username')
        if not username:
            return
        password = dialog.input('Password', option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password:
            return

    if wimp.login(username, password):
        addon.setSetting('session_id', wimp.session_id)
        addon.setSetting('country_code', wimp.country_code)
        addon.setSetting('user_id', unicode(wimp.user.id))


@plugin.route('/logout')
def logout():
    addon.setSetting('session_id', '')
    addon.setSetting('country_code', '')
    addon.setSetting('user_id', '')


@plugin.route('/play/<track_id>')
def play(track_id):
    media_url = wimp.get_media_url(track_id)
    if not media_url.startswith('http://') and not media_url.startswith('https://'):
        host, app, playpath = media_url.split('/', 3)
        media_url = 'rtmp://%s app=%s playpath=%s' % (host, app, playpath)
    li = ListItem(path=media_url)
    mimetype = 'audio/flac' if quality == Quality.lossless else 'audio/mpeg'
    li.setProperty('mimetype', mimetype)
    xbmcplugin.setResolvedUrl(plugin.handle, True, li)


def handle_errors(f):
    try:
        f()
    except HTTPError as e:
        if e.response.status_code in [401, 403]:
            dialog = xbmcgui.Dialog()
            dialog.notification(addon.getAddonInfo('name'), "Unauthorized", xbmcgui.NOTIFICATION_ERROR)
        else:
            raise e

if __name__ == '__main__':
    handle_errors(plugin.run)
